# Parallax Putting

A first-person mini-golf trainer for **alignment and parallax**, not an arcade game.
You stand beside and behind the ball at real eye height, your stance is never square
to the cup, and nothing on screen tells you where to aim. You look, judge, set the
putter face, putt, and only then see the numbers.

## Run it

Open `index.html` in a desktop browser (Chrome, Edge, Firefox or Safari). No build step
and no server: everything is plain scripts, and Three.js is in `lib/`. The fonts load
from Google Fonts when you are online and fall back to system fonts when you are not.

## Controls

| Input | Action |
| --- | --- |
| Click the course | Captures the mouse (pointer lock), so the cursor can never act as an aiming mark |
| Mouse left / right | Turn the putter around the ball. `Shift` for fine moves, or `A` / `D` |
| Hold left button, pull the mouse back, release | Backswing and putt. Backswing length sets the pace (pendulum stroke) |
| Sideways mouse drift during the backswing | Changes the stroke path, which nudges the start line |
| Arrow keys, right-drag, mouse wheel | Turn your head. `C` re-centres it |
| `Esc` or right-click while holding | Cancel the backswing |
| `Space` (ball rolling) | Hold to speed the roll up |
| `Enter` / `R` / `V` (after the shot) | Next hole / retry the same hole / view from behind the true line |
| `M` | Menu |

Touch screens: one finger turns the putter, two fingers look around, the pad at the
bottom right makes the stroke.

## What it trains

* **No aiming aids before the shot**: no lines, arrows, crosshair, grid, distance, power
  meter, ghost ball or visible cursor. The putter is a plain blade with no sight line.
* **Real parallax**: the camera is your eyes, 1.55 m up (adjustable), 0.55 m behind and
  0.30 m to the side of the ball (mirrored for left-handers). Turning your head rotates
  the eyes around a neck pivot, as it does in real life.
* **A stance that lies to you**: the game sets your stance a random number of degrees
  off the true line (more on harder levels). On "awkward angle" holes you stand
  parallel to the borders while the cup is 15–32° off to one side.
* **Eight situations**: straight, slight left, slight right, long, short, cup partly
  hidden by an obstacle, bank shot (block or dog-leg with a 45° cushion), awkward angle
  to the stance. Expert adds an open green with walls far away and plain surfaces.

After the ball stops you get: club alignment error, the ball's actual start line, where
it finished (left/right, short/long), distance from the hole, the finish direction from
the start (straight putts), the situation, and how far off the line your stance was. A
white ribbon shows your putt and a gold one shows the true line. `V` crouches you behind
the true line so you can compare what it looked like from your stance.

## Modes and difficulty

* **Practice**: a new random hole every putt (or retry the same one).
* **Course**: eight fixed holes, one per situation; the stance shifts slightly on each retry.

| Level | Cup Ø | Putts | Stance off the line |
| --- | --- | --- | --- |
| Easy | 14 cm | 1–3 m | 0–9° |
| Medium | 10.8 cm (regulation) | 1.8–5 m | 3–18° |
| Hard | 10.8 cm | 3–8 m, narrow lanes, obstacles, banks | 7–28° |
| Expert | 9 cm | 4–12 m, minimal visual cues | 12–38° |

## Statistics

Every putt is stored in the browser (`localStorage`). The statistics page shows total
putts, average alignment error with a first-vs-last trend, average distance from the
hole, left/right and short/long bias, best and worst alignment, the share of putts
within 1°, 2°, 5° and 10°, a per-putt chart with a 10-putt running average, and a
breakdown by situation. Filter by difficulty; reset from the bottom of the page.

## Physics

All in `js/physics.js` (pure JavaScript, testable in Node):

* **Skid then roll.** The putt leaves the face sliding. Kinetic friction μk·g slows the
  ball and spins it up at (5/2)·μk·g/r until the contact point stops slipping, at which
  point it rolls at v = (5·v₀ + 2·w₀)/7 (angular momentum about the contact point is
  conserved).
* **Rolling resistance.** Constant deceleration (5/7)·Crr·g. With Crr = 0.08 the
  surface runs about 10 ft on a Stimpmeter.
* **Borders.** Normal restitution 0.62 plus Coulomb friction on the tangential velocity
  and on the forward roll during the impact. The ball keeps part of its roll, so it
  skids and curls a little after a cushion, as real balls do.
* **The cup is 3-D.** The rim is a circular edge with friction and the cup a cylinder,
  so the ball pivots over the near edge, falls, and either catches the back of the cup
  or hops out. A centred putt drops at up to about 1.65 m/s on a regulation cup;
  off-centre putts lip out at lower speeds.
* **The stroke** is a pendulum: impact speed = ω × backswing length. Ball speed comes
  from a 1-D collision with the putter head (350 g, e = 0.8). The start direction is
  83 % face angle and 17 % stroke path.

The hidden line solver (`js/course.js`) finds the true line by simulation: the direct
line when it is open, otherwise single-cushion banks found by the mirror method and
then corrected with the real physics (or seeded from a simulated putt for dog-legs).
Every generated hole is checked to be holeable.

## Project layout

```
index.html        page structure (HUD, menu, result card, statistics page)
css/style.css     all styling, light and dark
lib/three.min.js  Three.js r128
js/config.js      every tunable number: physics, camera, controls, difficulty presets
js/rng.js         seeded random numbers (reproducible holes)
js/physics.js     ball, border and cup physics + the line simulator
js/course.js      the eight situations, the fixed course, layout validation, line solver
js/analysis.js    post-shot scoring (alignment, start line, finish position)
js/stats.js       saved shots and aggregate statistics
js/scene.js       Three.js world: green with a real cut-out cup, borders, obstacles, ball
js/club.js        the putter
js/player.js      stance and first-person head/eyes
js/input.js       mouse, keyboard, touch, pointer lock
js/ui.js          HUD, menu, result card, statistics page and chart
js/game.js        the game loop and phase machine
```

### Common changes

* Green speed: `surface.rollingResistance` in `config.js`.
* Eye position: `player.eyeHeight`, `eyeBehind`, `eyeSide`, `fovDeg`.
* How far off the line the stance is set: `difficulty.<level>.stanceOffsetDeg`.
* How often each situation appears: `difficulty.<level>.kinds`.
* A new situation: add a generator to `GEN` in `course.js`, give it a weight in
  `config.js` and a name in `kindLabels`.
