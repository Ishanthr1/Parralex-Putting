/*
 * rng.js — small seeded random number generator (mulberry32) so a layout can
 * be reproduced from its seed ("Retry this hole", fixed course holes).
 */
(function (root) {
  'use strict';
  const MG = (root.MG = root.MG || {});

  MG.createRng = function (seed) {
    let s = seed >>> 0;
    const next = () => {
      s = (s + 0x6d2b79f5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    return {
      seed,
      next,
      range: (a, b) => a + (b - a) * next(),
      int: (a, b) => Math.floor(a + (b - a + 1) * next()),
      sign: () => (next() < 0.5 ? -1 : 1),
      chance: (p) => next() < p,
      // weights: { key: weight }
      pick(weights) {
        const keys = Object.keys(weights).filter((k) => weights[k] > 0);
        const total = keys.reduce((s2, k) => s2 + weights[k], 0);
        let x = next() * total;
        for (const k of keys) {
          x -= weights[k];
          if (x <= 0) return k;
        }
        return keys[keys.length - 1];
      }
    };
  };

  MG.randomSeed = () => Math.floor(Math.random() * 2147483647);
})(typeof window !== 'undefined' ? window : globalThis);
