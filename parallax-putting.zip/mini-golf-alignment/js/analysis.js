/*
 * analysis.js — scores a finished shot. Runs only after the ball has stopped.
 *
 * Sign convention for every angle and lateral distance: positive = RIGHT
 * (as seen by the player looking down the line), negative = LEFT.
 */
(function (root) {
  'use strict';
  const MG = (root.MG = root.MG || {});
  const U = MG.Util, Ph = MG.Physics;
  const DEG = U.DEG;

  /*
   * shot: { faceYaw, launchYaw, speed, final:[x,z], holed, rimTouched, wallHits, path:[[x,z],…] }
   */
  function evaluate(L, shot) {
    const world = L.world;
    const target = { x: L.hole[0], z: L.hole[1] };
    const D = Math.hypot(L.hole[0], L.hole[1]);

    // The true line: the solved line closest to what the player actually chose.
    let cand = L.candidates[0], bestGap = Infinity;
    for (const c of L.candidates) {
      const g = Math.abs(U.wrap(shot.launchYaw - c.angle));
      if (g < bestGap) {
        bestGap = g;
        cand = c;
      }
    }
    let ideal = cand.angle;
    let refSpeed = cand.kind === 'direct' ? Ph.speedForDistance(D + 0.3) : cand.speedRef;
    if (cand.kind === 'bank') {
      // A bank line depends a little on pace (the ball curls after the cushion),
      // so re-solve at the speed the player actually hit, if that pace could hole it.
      const r = Ph.refineAngle(world, 0, 0, target, cand.angle, shot.speed, 4 * DEG, 0.25 * DEG);
      if (r.minDist < 0.8 * L.holeR) {
        ideal = r.angle;
        refSpeed = shot.speed;
      }
    }

    const ip = Ph.simulateLine(world, 0, 0, ideal, refSpeed, { record: true, target });
    const idealPath = ip.points.slice(0, ip.minIdx + 1);
    idealPath.push([target.x, target.z]);
    const approach = cand.kind === 'direct' ? U.angleOf(target.x, target.z) : U.angleOf(ip.minVel[0], ip.minVel[1]);

    const ox = shot.final[0] - target.x, oz = shot.final[1] - target.z;
    const along = ox * U.dirX(approach) + oz * U.dirZ(approach); // + long
    const lateral = ox * U.rightX(approach) + oz * U.rightZ(approach); // + right

    const res = {
      kind: L.kind,
      label: L.label,
      lineKind: cand.kind,
      idealYaw: ideal,
      idealPath,
      puttLength: D,
      alignDeg: U.wrap(shot.faceYaw - ideal) / DEG,
      startDeg: U.wrap(shot.launchYaw - ideal) / DEG,
      stanceDeg: U.wrap(L.stanceYaw - ideal) / DEG,
      holed: !!shot.holed,
      lipped: !shot.holed && !!shot.rimTouched,
      lateral: shot.holed ? 0 : lateral,
      along: shot.holed ? 0 : along,
      finalDist: shot.holed ? 0 : Math.hypot(ox, oz),
      finishDeg: null,
      speed: shot.speed
    };
    if (cand.kind === 'direct' && !shot.holed && Math.hypot(shot.final[0], shot.final[1]) > 0.05) {
      res.finishDeg = U.wrap(U.angleOf(shot.final[0], shot.final[1]) - U.angleOf(target.x, target.z)) / DEG;
    }
    return res;
  }

  // ---- wording helpers (shared by the result card and the stats page)
  const side = (v) => (v < 0 ? 'left' : 'right');
  function fmtDeg(v, digits) {
    const a = Math.abs(v);
    if (a < 0.05) return '0.0°';
    return a.toFixed(digits == null ? 1 : digits) + '° ' + side(v);
  }
  function fmtCm(m) {
    const cm = Math.abs(m) * 100;
    return cm >= 100 ? (cm / 100).toFixed(2) + ' m' : Math.round(cm) + ' cm';
  }
  function verdict(absDeg) {
    if (absDeg <= 1) return { text: 'Dead on', tone: 'good' };
    if (absDeg <= 2) return { text: 'Excellent', tone: 'good' };
    if (absDeg <= 5) return { text: 'Good', tone: 'ok' };
    if (absDeg <= 10) return { text: 'Off line', tone: 'warn' };
    return { text: 'Way off', tone: 'bad' };
  }

  MG.Analysis = { evaluate, fmtDeg, fmtCm, verdict, side };
})(typeof window !== 'undefined' ? window : globalThis);
