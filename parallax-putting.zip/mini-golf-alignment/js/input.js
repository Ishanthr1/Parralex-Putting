/*
 * input.js — mouse, keyboard and touch. It only reports raw intent
 * (rotate club, look, stroke start/move/release/cancel, key presses);
 * game.js decides what each one means in the current phase.
 *
 * The cursor is hidden over the course (and captured with pointer lock when
 * the browser allows it) so it can never be used as an aiming mark.
 */
(function (root) {
  'use strict';
  const MG = (root.MG = root.MG || {});
  const C = MG.CONFIG, U = MG.Util;
  const DEG = U.DEG;

  MG.Input = function (canvas, pad, h) {
    const K = C.controls;
    const keys = new Set();
    const st = { locked: false, lockFailed: !canvas.requestPointerLock, stroking: false, rightDrag: false, touches: new Map() };

    // ---------------- pointer lock
    function requestLock() {
      if (st.lockFailed || st.locked || !canvas.requestPointerLock) return;
      try {
        const p = canvas.requestPointerLock();
        if (p && p.catch) p.catch(() => (st.lockFailed = true));
      } catch (e) {
        st.lockFailed = true;
      }
    }
    function exitLock() {
      if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock();
    }
    document.addEventListener('pointerlockchange', () => {
      st.locked = document.pointerLockElement === canvas;
      if (!st.locked && st.stroking) {
        st.stroking = false;
        h.strokeCancel();
      }
      h.lockChange && h.lockChange(st.locked);
    });
    document.addEventListener('pointerlockerror', () => {
      st.lockFailed = true;
      h.lockChange && h.lockChange(false);
    });

    // ---------------- mouse
    canvas.addEventListener('mousedown', (e) => {
      if (e.button === 0) {
        if (!st.locked && !st.lockFailed && h.wantsLock()) {
          requestLock(); // the capturing click never starts a stroke
          return;
        }
        if (h.strokeStart()) st.stroking = true;
      } else if (e.button === 2) {
        if (st.stroking) {
          st.stroking = false;
          h.strokeCancel();
        } else st.rightDrag = true;
      }
    });
    root.addEventListener('mouseup', (e) => {
      if (e.button === 0 && st.stroking) {
        st.stroking = false;
        h.strokeRelease();
      } else if (e.button === 2) st.rightDrag = false;
    });
    root.addEventListener('mousemove', (e) => {
      const dx = e.movementX || 0, dy = e.movementY || 0;
      if (!dx && !dy) return;
      if (!st.locked && e.target !== canvas && !st.stroking) return;
      if (st.rightDrag) h.look(dx * K.lookDegPerPx * DEG, -dy * K.lookDegPerPx * DEG);
      else if (st.stroking) h.strokeMove(dx, dy);
      else h.club(dx * (e.shiftKey ? K.clubFineDegPerPx : K.clubDegPerPx) * DEG);
    });
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      h.look(0, -Math.sign(e.deltaY) * 3 * DEG);
    }, { passive: false });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // ---------------- keyboard
    const OWN = new Set(['KeyA', 'KeyD', 'KeyQ', 'KeyE', 'KeyC', 'KeyR', 'KeyV', 'KeyM', 'Space', 'Enter', 'Escape', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown']);
    root.addEventListener('keydown', (e) => {
      const tag = (e.target && e.target.tagName) || '';
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (!h.playing()) return;
      if (OWN.has(e.code)) e.preventDefault();
      if (e.code === 'Escape' && st.stroking) {
        st.stroking = false;
        h.strokeCancel();
        return;
      }
      if (!e.repeat) h.key(e.code, true);
      keys.add(e.code);
    });
    root.addEventListener('keyup', (e) => {
      keys.delete(e.code);
      if (h.playing()) h.key(e.code, false);
    });
    root.addEventListener('blur', () => keys.clear());

    // Held keys, polled every frame.
    function poll(dt) {
      const fine = keys.has('ShiftLeft') || keys.has('ShiftRight');
      const rate = (fine ? K.clubKeyDegPerSec * 0.25 : K.clubKeyDegPerSec) * DEG * dt;
      if (!st.stroking) {
        if (keys.has('KeyA') || keys.has('KeyQ')) h.club(-rate);
        if (keys.has('KeyD') || keys.has('KeyE')) h.club(rate);
      }
      const look = K.lookKeyDegPerSec * DEG * dt;
      if (keys.has('ArrowLeft')) h.look(-look, 0);
      if (keys.has('ArrowRight')) h.look(look, 0);
      if (keys.has('ArrowUp')) h.look(0, look * 0.7);
      if (keys.has('ArrowDown')) h.look(0, -look * 0.7);
      return { fast: keys.has('Space') };
    }

    // ---------------- touch: one finger turns the putter, two fingers look,
    // the pad on the right makes the stroke.
    canvas.addEventListener('pointerdown', (e) => {
      if (e.pointerType !== 'touch') return;
      st.touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'touch' || !st.touches.has(e.pointerId)) return;
      const p = st.touches.get(e.pointerId);
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (st.touches.size >= 2) h.look((dx * K.lookDegPerPx * DEG) / 2, (-dy * K.lookDegPerPx * DEG) / 2);
      else h.club(dx * K.clubFineDegPerPx * 1.5 * DEG);
    });
    const endTouch = (e) => st.touches.delete(e.pointerId);
    canvas.addEventListener('pointerup', endTouch);
    canvas.addEventListener('pointercancel', endTouch);

    let padY = null;
    pad.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (!h.strokeStart()) return;
      st.stroking = true;
      padY = { x: e.clientX, y: e.clientY };
      pad.setPointerCapture && pad.setPointerCapture(e.pointerId);
    });
    pad.addEventListener('pointermove', (e) => {
      if (!st.stroking || !padY) return;
      const dx = e.clientX - padY.x, dy = e.clientY - padY.y;
      padY = { x: e.clientX, y: e.clientY };
      h.strokeMove(dx * 0.6, dy * 1.4);
    });
    const padEnd = () => {
      if (st.stroking) {
        st.stroking = false;
        h.strokeRelease();
      }
      padY = null;
    };
    pad.addEventListener('pointerup', padEnd);
    pad.addEventListener('pointercancel', () => {
      if (st.stroking) {
        st.stroking = false;
        h.strokeCancel();
      }
      padY = null;
    });

    return { st, poll, requestLock, exitLock };
  };
})(typeof window !== 'undefined' ? window : globalThis);
